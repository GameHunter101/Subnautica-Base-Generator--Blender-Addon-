def initialize():
    global to_windows
    to_windows = []